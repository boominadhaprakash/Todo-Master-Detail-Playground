import Foundation
import UIKit

open class screenSize {
    open class var width:CGFloat {return 375.0}
    open class var height:CGFloat {return 667.0}
}
